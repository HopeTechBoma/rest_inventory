class User {
    final String name;
    final String image;
    final String profession;

    User(
        this.name,
        this.image,
        this.profession
    );
}

List users = [];